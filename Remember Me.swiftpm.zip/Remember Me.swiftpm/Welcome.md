#  Welcome to Remember Me

## Important note for gameplay

- Please run this game in Protrait Mode.

- Please turn on sound for best experience.


## Credit for external resource

### Sounds:

- BGM

Hold Me Closer - Instrumental Version, Livingrooms  (Licensed under my Artlist Subscription)

- Sound Effects

Arcade Tap, Arcade Win, Arcade Lose  (Licensed under Mixkit Sound Effects Free License); 

Payment Confirmation Sound, Message Sent Sound  (Recorded from my iPhone);

Grocery Store Background Noise, Jeff Hottman, https://www.youtube.com/watch?v=WoxnL5dakyA  (Licensed under CC BY)


### Graphics:

- Background

Cityscape in Night Pixel Art, Reddits  (This image was modified by the developer to fit app's design and implement infinite scrolling background)

Apple Card  (Exported from my Mac Wallet assets)


### Coding:

- Reference

This app is an individual work, and I use resources from the following resources as reference and learning materials.

StackOverflow

Apple Developer Forum

Hacking with Swift

GitHub
