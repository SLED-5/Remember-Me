//
//  Tip.swift
//  Remember Me
//
//  Created by Gabriel Zhang on 4/4/23.
//

import Foundation

struct Tip {
    var from: String
    var content: String
    var instruction: String
}
